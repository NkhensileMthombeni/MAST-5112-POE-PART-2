# Christoffel Menu App (Expo / React Native)

This is a simple cross-platform React Native app (Expo) that matches the wireframes and implementation plan.

## Features
- Menu list (search + filter)
- Add / Edit menu items
- Item details + delete
- Local persistence using AsyncStorage

## Setup (run locally)
1. Install Expo CLI (if not installed):
   ```
   npm install -g expo-cli
   ```
2. Extract the zip and open the project folder in VS Code.
3. Install dependencies:
   ```
   npm install
   ```
4. Start the app:
   ```
   expo start
   ```
5. Use an emulator or the Expo Go app on your phone.

## Notes
- This project uses AsyncStorage for local persistence.
- Dependencies are listed in package.json. If you prefer yarn, use `yarn install`.
