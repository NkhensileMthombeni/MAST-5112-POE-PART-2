import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import MenuList from '../screens/MenuList';
import AddItem from '../screens/AddItem';
import ItemDetails from '../screens/ItemDetails';

const Stack = createNativeStackNavigator();

export default function AppNavigator() {
  return (
    <Stack.Navigator initialRouteName="MenuList">
      <Stack.Screen name="MenuList" component={MenuList} options={{ title: 'Menu' }} />
      <Stack.Screen name="AddItem" component={AddItem} options={{ title: 'Add / Edit Item' }} />
      <Stack.Screen name="ItemDetails" component={ItemDetails} options={{ title: 'Details' }} />
    </Stack.Navigator>
  );
}
