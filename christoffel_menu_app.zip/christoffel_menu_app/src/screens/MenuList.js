import React, { useEffect, useState } from 'react';
import { SafeAreaView, View, Text, TextInput, FlatList, Pressable, StyleSheet } from 'react-native';
import DishCard from '../components/DishCard';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { v4 as uuidv4 } from 'uuid';

// A small fallback for uuidv4 if not available in environment
function genId() {
  return 'id-' + Math.random().toString(36).slice(2,9);
}

export default function MenuList({ navigation }) {
  const [items, setItems] = useState([]);
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('All');

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      loadItems();
    });
    loadItems();
    return unsubscribe;
  }, []);

  async function loadItems() {
    try {
      const raw = await AsyncStorage.getItem('@menu_items');
      if (raw) setItems(JSON.parse(raw));
      else setItems(sampleData());
    } catch (e) {
      console.warn('Failed reading items', e);
    }
  }

  async function saveItems(next) {
    setItems(next);
    try {
      await AsyncStorage.setItem('@menu_items', JSON.stringify(next));
    } catch (e) {
      console.warn('Failed saving items', e);
    }
  }

  function sampleData() {
    return [
      { id: genId(), name: 'Tomato Soup', description: 'Warm tomato soup with basil.', course: 'Starter', price: 45.00 },
      { id: genId(), name: 'Grilled Chicken', description: 'Herb-marinated grilled chicken with sides.', course: 'Main', price: 120.00 },
      { id: genId(), name: 'Chocolate Mousse', description: 'Light and airy chocolate mousse.', course: 'Dessert', price: 55.00 },
    ];
  }

  function filtered() {
    return items.filter(d => (filter === 'All' || d.course === filter) && d.name.toLowerCase().includes(query.toLowerCase()));
  }

  return (
    <SafeAreaView style={{flex:1}}>
      <View style={styles.header}>
        <TextInput placeholder="Search..." value={query} onChangeText={setQuery} style={styles.search} />
        <Pressable style={styles.addBtn} onPress={() => navigation.navigate('AddItem', { mode: 'add' })}>
          <Text style={{color:'#fff'}}>+ Add</Text>
        </Pressable>
      </View>

      <View style={styles.filterRow}>
        {['All','Starter','Main','Dessert'].map(c => (
          <Pressable key={c} onPress={() => setFilter(c)} style={[styles.filterBtn, filter===c && styles.filterActive]}>
            <Text style={filter===c ? styles.filterActiveText : styles.filterText}>{c}</Text>
          </Pressable>
        ))}
      </View>

      <FlatList
        data={filtered()}
        keyExtractor={i => i.id}
        renderItem={({item}) => (
          <DishCard item={item} onPress={() => navigation.navigate('ItemDetails', { id: item.id })} />
        )}
        contentContainerStyle={{paddingBottom: 40}}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', padding: 12 },
  search: { flex: 1, padding: 10, borderRadius: 8, backgroundColor: '#f1f1f1' },
  addBtn: { marginLeft: 10, padding: 10, backgroundColor: '#1e90ff', borderRadius: 8 },
  filterRow: { flexDirection: 'row', paddingHorizontal: 12, paddingVertical: 8, justifyContent: 'space-between' },
  filterBtn: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20, borderWidth: 1, borderColor: '#ddd' },
  filterActive: { backgroundColor: '#1e90ff', borderColor: '#1e90ff' },
  filterText: { color: '#333' },
  filterActiveText: { color: '#fff' }
});
