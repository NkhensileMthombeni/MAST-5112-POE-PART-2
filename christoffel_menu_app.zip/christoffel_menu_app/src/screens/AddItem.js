import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Pressable, ScrollView, StyleSheet, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

function genId() {
  return 'id-' + Math.random().toString(36).slice(2,9);
}

export default function AddItem({ navigation, route }) {
  const mode = route.params?.mode || 'add'; // 'add' or 'edit'
  const editId = route.params?.id;

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [course, setCourse] = useState('Main');
  const [items, setItems] = useState([]);

  useEffect(() => {
    (async ()=> {
      const raw = await AsyncStorage.getItem('@menu_items');
      const data = raw ? JSON.parse(raw) : [];
      setItems(data);
      if (mode === 'edit' && editId) {
        const it = data.find(d => d.id === editId);
        if (it) {
          setName(it.name); setDescription(it.description); setPrice(String(it.price)); setCourse(it.course);
        }
      }
    })();
  }, []);

  async function save() {
    if (!name.trim()) return Alert.alert('Validation', 'Please provide a dish name.');
    const num = parseFloat(price);
    if (Number.isNaN(num)) return Alert.alert('Validation', 'Please provide a numeric price.');

    let next;
    if (mode === 'edit' && editId) {
      next = items.map(d => d.id === editId ? { ...d, name, description, course, price: num } : d);
    } else {
      next = [{ id: genId(), name, description, course, price: num }, ...items];
    }

    try {
      await AsyncStorage.setItem('@menu_items', JSON.stringify(next));
      navigation.goBack();
    } catch (e) {
      console.warn('Save failed', e);
    }
  }

  return (
    <ScrollView contentContainerStyle={{padding:16}}>
      <Text style={styles.label}>Dish Name *</Text>
      <TextInput style={styles.input} value={name} onChangeText={setName} placeholder="E.g. Butter Chicken" />

      <Text style={styles.label}>Description</Text>
      <TextInput style={[styles.input, {height:100}]} value={description} onChangeText={setDescription} multiline />

      <Text style={styles.label}>Course</Text>
      <View style={styles.courseRow}>
        {['Starter','Main','Dessert'].map(c => (
          <Pressable key={c} onPress={() => setCourse(c)} style={[styles.courseBtn, course===c && styles.courseActive]}>
            <Text style={course===c ? styles.courseActiveText : null}>{c}</Text>
          </Pressable>
        ))}
      </View>

      <Text style={styles.label}>Price (ZAR)</Text>
      <TextInput style={styles.input} value={price} onChangeText={setPrice} keyboardType="numeric" placeholder="e.g. 65.00" />

      <Pressable style={styles.saveBtn} onPress={save}><Text style={{color:'#fff'}}>Save</Text></Pressable>
      <Pressable style={styles.cancelBtn} onPress={() => navigation.goBack()}><Text>Cancel</Text></Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  label: { marginTop: 12, marginBottom: 6, fontWeight: '600' },
  input: { backgroundColor: '#fff', padding: 12, borderRadius: 8, borderWidth: 1, borderColor: '#eee' },
  courseRow: { flexDirection: 'row', marginBottom: 8 },
  courseBtn: { padding: 10, borderRadius: 8, borderWidth: 1, borderColor: '#ddd', marginRight: 8 },
  courseActive: { backgroundColor: '#1e90ff', borderColor: '#1e90ff' },
  courseActiveText: { color: '#fff' },
  saveBtn: { marginTop: 16, padding: 12, backgroundColor: '#28a745', borderRadius: 8, alignItems: 'center' },
  cancelBtn: { marginTop: 10, padding: 12, alignItems: 'center' }
});
