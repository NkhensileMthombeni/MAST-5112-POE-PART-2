import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, Pressable, Alert, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function ItemDetails({ route, navigation }) {
  const id = route.params?.id;
  const [item, setItem] = useState(null);

  useEffect(() => {
    (async ()=> {
      const raw = await AsyncStorage.getItem('@menu_items');
      const data = raw ? JSON.parse(raw) : [];
      const found = data.find(d => d.id === id);
      if (found) setItem(found);
    })();
  }, []);

  async function remove() {
    Alert.alert('Confirm', 'Delete this item?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => {
        try {
          const raw = await AsyncStorage.getItem('@menu_items');
          const data = raw ? JSON.parse(raw) : [];
          const next = data.filter(d => d.id !== id);
          await AsyncStorage.setItem('@menu_items', JSON.stringify(next));
          navigation.goBack();
        } catch (e) {
          console.warn('Delete failed', e);
        }
      } }
    ]);
  }

  if (!item) return <ScrollView contentContainerStyle={{padding:16}}><Text>Loading...</Text></ScrollView>;

  return (
    <ScrollView contentContainerStyle={{padding:16}}>
      <Text style={styles.name}>{item.name}</Text>
      <Text style={styles.course}>{item.course} · R {item.price.toFixed(2)}</Text>
      <Text style={styles.desc}>{item.description}</Text>

      <View style={{flexDirection:'row', marginTop:20}}>
        <Pressable style={styles.editBtn} onPress={() => navigation.navigate('AddItem', { mode: 'edit', id: item.id })}>
          <Text style={{color:'#fff'}}>Edit</Text>
        </Pressable>
        <Pressable style={styles.delBtn} onPress={remove}>
          <Text style={{color:'#fff'}}>Delete</Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  name: { fontSize:22, fontWeight:'700' },
  course: { marginTop:8, color:'#666' },
  desc: { marginTop:12, lineHeight:20 },
  editBtn: { padding:12, backgroundColor:'#1e90ff', borderRadius:8, marginRight:8 },
  delBtn: { padding:12, backgroundColor:'#dc3545', borderRadius:8 }
});
