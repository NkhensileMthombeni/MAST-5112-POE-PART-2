import React from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';

export default function DishCard({ item, onPress }) {
  return (
    <Pressable onPress={onPress} style={styles.card}>
      <View>
        <Text style={styles.name}>{item.name}</Text>
        <Text numberOfLines={2} style={styles.desc}>{item.description}</Text>
        <Text style={styles.price}>R {item.price.toFixed(2)}</Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    padding: 12,
    backgroundColor: '#fff',
    borderRadius: 8,
    marginVertical: 6,
    marginHorizontal: 12,
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 6,
    elevation: 2,
  },
  name: { fontSize: 16, fontWeight: '600' },
  desc: { fontSize: 13, color: '#555', marginTop: 6 },
  price: { marginTop: 8, fontWeight: '700' }
});
