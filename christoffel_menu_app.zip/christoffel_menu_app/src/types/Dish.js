// Simple Dish type (for reference)
// { id: string, name: string, description: string, course: 'Starter'|'Main'|'Dessert', price: number }
